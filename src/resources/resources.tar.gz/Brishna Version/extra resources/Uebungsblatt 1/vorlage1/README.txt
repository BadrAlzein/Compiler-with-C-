In der vorlage2 sind dazugekommen:

	include/lib/Chain.h
	include/lib/Queue.h
	include/thread/*

	src/lib/Queue.cc
	src/mainAct.cc
	src/mainCo.cc

Alle andere Dateien wurden von vorlage1 �bernommen.