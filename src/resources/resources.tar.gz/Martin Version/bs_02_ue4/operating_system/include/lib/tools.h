#ifndef tools_h
#define tools_h

void *memcpy(void *dest, const void *src, unsigned n);

#endif