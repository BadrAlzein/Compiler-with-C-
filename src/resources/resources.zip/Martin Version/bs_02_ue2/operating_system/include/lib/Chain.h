#ifndef Chain_h
#define Chain_h

struct Chain {
	Chain* next;
};

#endif


