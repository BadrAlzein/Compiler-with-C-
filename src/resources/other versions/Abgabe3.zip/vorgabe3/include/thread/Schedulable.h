#ifndef Schedulable_h
#define Schedulable_h

/*
 * Schedulable: Diese Klasse implementiert ein Element
 *		der Ready-Liste des Schedulers
 *
 *	Anmerkung: Die Klasse ist von Chain abgeleitet,
 *	damit Instanzen dieser Klasse verkettet werden koennen.
 *	Hier wuerden typischerweise Informationen
 *	wie prozesspezifische Laufzeitstatistiken,
 *	Prioritaeten etc. verwaltet werden.
 *	Gegenwaertig brauchen wir diese Informationen
 *	aber noch nicht und die Klasse ist deshalb vorlaeufig leer.
 *
 */

#include "lib/Chain.h"

class Schedulable: public Chain {
public:
explicit Schedulable(int slice = 1)
	{ 
		quantum(slice);
		setQuantum(slice);
	}

	void quantum(int slice)
	{ 
		this->slice = slice;
	}

	int quantum()
	{ 
		return slice;
	}

	void setQuantum(int proQuantum)
	{
		this->proQuantum = proQuantum;
	}

	int getQuantum()
	{
		return proQuantum;
	}

private:
int slice;
int proQuantum;		// heiw wird das Quantum mit dem die Prozesse initialisiert 
};

#endif
