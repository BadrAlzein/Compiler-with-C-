#include "device/PIT.h"

PIT::PIT():control(CONTROL_PORT) , data(DATA_PORT)
{
}
PIT::PIT(int us):control(CONTROL_PORT), data(DATA_PORT){
    this->interval(us);  // hier wird den Interval aufgerufen und mit dem Us Param. 
}
void PIT ::interval(int us){
    int counter = (us*1000)/TIME_BASE;      //  hier wird den Zahl berchnet, und eingegebnen "us" wird in Nano umgewandelt und um der TimeBase 
    control.write(0x34);                    // hier haben wir Steuer Wort wir wählen folgenen aus schreib in low dann high und mode 2 und bit schreibweiße und zähler 0.   00110100
    char low = (counter & 0xff);          //zweiten 8 bits verunden mit 00001111  und low Rigiester in in Daten Rigiester schreiben                // hier wird den Steuerwort ubergegeben und die werte des SteuerRister ins Controllor Rigiester geschrieben  
    char high = (counter >> 8)  ;   //den ersten 8 bits verunden mit 11110000 und zeilen um 8 bit verschiieben und high byte in Daten regiser schrieben 
    
    data.write(low);
    data.write(high);
    
}

