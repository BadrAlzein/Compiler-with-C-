#include "device/CgaChannel.h"
#include "device/CgaAttr.h"
#include "device/CgaScreen.h"

CgaChannel :: CgaChannel() {
    CgaScreen();
}

CgaChannel :: CgaChannel ( const CgaAttr& attr)
{
    CgaChannel();
    setAttr(attr);
}
int tmpcolumn ; 
int tmprow ;

int CgaChannel :: write (const char* data , int size){
for(int i = 0 ; i < size ; i++){
    if (data[i]=='\n')
    {
       zeileInc();
    }
    else if (data[i]=='\r')
    {
        cursorFort();
    }
    else {
        show(data[i]);

    }
/*
     getCursor(tmpcolumn, tmprow);

     //setCursor(tmpcolumn, (ROWS - 1));
     
    int shifter = tmprow - (ROWS + 1);
    if (shifter > 0) {
        scroll();
        setCursor(tmpcolumn, (ROWS - 1));
    }
    */
    
}
return (size -1);

} 


void CgaChannel :: blueScreen(const char* error){
    
    CgaAttr attError ( CgaAttr :: WHITE , CgaAttr :: BLUE , false);
    setAttr(attError);
    clear();
    /* int tempo =0; */

    for(int i = 0 ; i <ROWS ; i++){
        for(int j = 0 ; j < COLUMNS ; j++)
        {
            setCursor(j, i);
            show(' ');
            
        }

    }

    setCursor(25, 15);
    int i = 0;
    while (error[i] != '\0'){
    	
    	i++;
    	
    }
    write(error, i);


}

void CgaChannel :: zeileInc (){
    getCursor(tmpcolumn, tmprow);
    if(tmprow == 24){
        scroll();
        tmprow = ROWS -1 ; 
    }
    else
    {
        
        setCursor(0,tmprow +1);
    }
}

void CgaChannel :: cursorFort(){
    getCursor(tmpcolumn, tmprow);
    setCursor(0,tmprow);
    

} 



