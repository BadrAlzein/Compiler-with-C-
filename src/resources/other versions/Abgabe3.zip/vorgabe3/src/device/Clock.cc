#include "device/Clock.h"
#include "device/PIC.h"
#include "interrupts/InterruptVector.h"
#include "thread/ActivityScheduler.h"
#include "device/CgaChar.h"
#include "io/PrintStream.h"
#include "device/CPU.h"
#include "device/CgaChannel.h"

/* 
CgaChannel cga;         // unser CGA-Ausgabekanal
PrintStream out(cga);   // unseren PrintStream mit Ausgabekanal verknuepfen */

Clock::Clock():Gate(Timer) 
{

}
Clock::Clock(int us) : Gate(Timer), PIT(us){
    this->windup(us);  // hiwe wird die Werte gesetzt 
}

void Clock ::windup(int us) {
    tick = 0 ;    // unsere Zähler wird hier eingestellt 
    pic.enable(PIC::PIT); // hier wird PIT angestellt und bei PIC angemeldet 
    this->interval(us); // hier setzt man den Intervall 

}

void Clock ::handle(){
    tick++;
    pic.ack();              // Hier wird beim Pic bestäigit 
    scheduler.checkSlice(); // hier wird Checkslice aufgerufen um die Zeitscheibe zu verwalten 

    //char* propelle = (char*) "-\\|/";

    /* scheduler.reschedule();
    tick++;
  
      
    /* cga.setCursor(0,0);
    out.print(propelle[(ticks()/50) % 4]);
  */

}