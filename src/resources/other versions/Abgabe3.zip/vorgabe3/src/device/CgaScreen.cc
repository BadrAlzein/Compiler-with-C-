#include "device/CgaScreen.h"
#include "lib/tools.h"
#include "device/CgaAttr.h"
#include"device/CgaChar.h"



CgaScreen :: CgaScreen() : index ( Indexregister) , data(Datenregister), screen  ((CgaChar*) offsetVram) {
    
    clear();
}

CgaScreen :: CgaScreen(CgaAttr attr) : index(Indexregister), data(Datenregister), screen  ((CgaChar*) offsetVram) {
    this -> CgaScreen :: attr = attr ; 
    clear();
}

void CgaScreen :: clear(){
const CgaAttr cleaAttr ; 
for( int i =0 ; i <= (Screen :: ROWS * Screen ::COLUMNS)-1; i++){
    
        screen[i].setChar(' ');
        screen[i].setAttr(attr);
    
}
setCursor(0,0);
}

void CgaScreen :: scroll () {
     int column , row ; 
    getCursor(column , row);
    memcpy(screen, screen + COLUMNS , 3840 );
    for( int i = ROWS * COLUMNS -80 ; i < 2000 ; i++){
        CgaScreen :: screen[i].setAttr(attr);
        CgaScreen :: screen[i].setChar(' ');
    }
    
    
    setCursor(0,24);
}

void CgaScreen :: setCursor (int column , int row) {
    unsigned int pos = (row * Screen :: COLUMNS) + column ;
    unsigned int posHigh = (pos >> 8 ) & 0xff;
    unsigned int posLow = pos & 0xff; 
    
//lowbyte
    index.write(LOW);
    data.write(posLow);
//Highbyte
    index.write(HIGH);
    data.write(posHigh);

}

void CgaScreen :: getCursor ( int& column , int& row){

unsigned int pos ;
index.write(HIGH);
 unsigned posHigh = data.read() << 8;

 index.write(LOW);
 unsigned posLow = data.read();

pos = posHigh | posLow ; 
column = (int) pos % COLUMNS;
row = (int) pos / COLUMNS;  

}

void CgaScreen :: show(char ch, const CgaAttr& attr) {
    int column , row ; 
    getCursor(column , row);
    unsigned pos = row * COLUMNS + column;

        screen[pos].setAttr(attr);
        screen[pos].setChar(ch);

       	if (column == COLUMNS - 1) {
				if (row == ROWS - 1) {
                
					scroll();
					row = ROWS - 1;

				} else {
					row++;
				}
				column = 0;
			} else {
				
				column++;
			}
			setCursor(column, row); 


}





