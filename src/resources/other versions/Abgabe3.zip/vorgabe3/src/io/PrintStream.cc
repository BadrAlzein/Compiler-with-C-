#include "io/PrintStream.h"
#include "io/OutputChannel.h"

PrintStream :: PrintStream(OutputChannel* chan) : channel(*chan)
{
}

PrintStream :: PrintStream(OutputChannel& chan) : channel(chan)
{
}

void PrintStream :: print(const char* str){
	
	int i = 0;
	while (str[i] != '\0'){
		i++;		
	}
	channel.write(str, i);	
}

void PrintStream :: print(char ch){
	channel.write(ch);
}

void PrintStream :: println(const char* str){
	print(str);
	println();
}

void PrintStream :: println(){
	print('\n');			
	}

void PrintStream :: print (int x, int base){
	
	if (x<0) {	

		x *= (-1);	
		print('-');
		print((unsigned) x, base);
	}
	else {
		this->print((unsigned)x, base);
	}
	
	
}

void PrintStream :: print(unsigned x, int base){

	
	if(((base != 2) && (base != 10) && (base != 16))){
		print("unvalid basis");
		return;	
	}

	if (base == BINARY){
		print("0b") ; 
	}
	if (base == DECIMAL){
		print("0d");
	}
	if (base == HEX){
		print("0x") ; 
	} 
	int max = 32 ; 
	char result[max];
	int resultLength = 0;
	char digits []= {"0123456789ABCDEF"};

	while (x > 0)
	{
		result[resultLength] = digits[(x % base)];
		x = x / base;
		resultLength++;
	}
	while (resultLength)
	{
		channel.write(result[resultLength - 1]);
		resultLength--;
	}

	

	}



void PrintStream :: print(void* p){

	print((unsigned int) p, HEX);
}


		