
#include "../include/thread/Scheduler.h"
#include "../include/thread/ActivityScheduler.h"
#include "interrupts/IntLock.h"

void Scheduler::schedule(Schedulable* sched)
{
    IntLock lock;
    readylist.enqueue(sched);           //hier wird  die  die vorgegeben Funk enqueue() benutzt 
}

void Scheduler::remove(Schedulable* sched)
{
    IntLock lock;
    readylist.remove(sched);            //hier wird  die vorgegebene Funk remove() benutzt
}

void Scheduler::reschedule()
{
    IntLock lock;
    Schedulable* sched = (Schedulable*) readylist.dequeue(); // hier wird die vorgegebene Funk dequeue() benutzt 
    activate(sched);                                        // impliemntieren die Funk  von ActivityScheduler , wo die nächste Aktivität abgefragt wird, was in der Liste starten soll! 
}       

void Scheduler::checkSlice()
{
    IntLock lock;

    Activity* aktiv = (Activity*) scheduler.active();

    if (aktiv) {                                        // hier wird geprüft, ob eineAktivität existiertiet ist
        if (aktiv->quantum() == 0) {                    //falls hier das  Quantum lief 
            int quantum = aktiv->getQuantum();
            aktiv->quantum(quantum);                    // hier wird das Quantum neue gesetzt also wie es virher geweessen ist. 
            this->reschedule();                         // hier wird Reschdule() aufgerufen 
        } else {
            int slice = aktiv->quantum();               // falls das seitscheibe nicht abgelaufen dann wird vom SLeice -1 gezogen und übergben wier es den AkTIVEN wieder.  
            slice--;
            aktiv->quantum(slice);
        }
    }
}