
#include "thread/Activity.h"
#include "thread/ActivityScheduler.h"
#include "interrupts/IntLock.h"
// Activity installiersieren und die zustand soll BLOCKED ! 
Activity :: Activity(void* tos):Coroutine(tos), actuell(0),zustand(BLOCKED){}

Activity :: Activity(){
this-> actuell = 0 ;  // Activity instalieren 
this -> zustand = BLOCKED; // Activity blockieren 
scheduler.start(this); // Activity starten  
}
Activity :: ~Activity()           // hier ist Destruktor
{
    scheduler.kill(this);       //aktuell laufende prozess terminieren
}
void Activity :: sleep() {
    scheduler.suspend();  // prozesse BLockieren "ActivitySchuduler"
} 
void Activity :: wakeup() {
    IntLock lock;
    this-> zustand = READY;
    scheduler.schedule(this); // wird den Prozesse in Readyliste gebracht und aud Ready zustand gesetzt 
}
void Activity :: yield() {
    scheduler.reschedule();// die laufende Prozesse wird vom Cpu abgeben und zum Readylist gebracht 
}
void Activity:: exit() {
    if(this -> actuell !=0) {  // //wenn diese Aktivität eine Aktivität besitzt
        this-> actuell->wakeup();  // dann wird die aufgewächt 
    }
    scheduler.exit();  //exit aufrufen 
}

void Activity :: join(){
    IntLock lock;
    Activity* actuellactive = (Activity*) scheduler.active(); // laufende Prozesse, was hier getsport werden muss 
    if(this != actuellactive && !(this-> isZombie())){       //Prufen ob der Prozesse nicht Zombi anderes gesagt existiert und nicht die gleiche laufende Prozess
    this -> actuell = ((Activity*)scheduler.active()); // in der Paramieter actuell wird actulle Acktivitigespeichet 
    scheduler.suspend(); // laufende Prozess Supendieren 
    } 
}

