
#include "thread/Coroutine.h"
#include "device/CPU.h"


void Coroutine::startup(Coroutine* obj)  {
    CPU::enableInterrupts();                //hier wird eine explizites einschaltung der Interrupts bei der  Erstellung von  einer neuen Coroutine
    obj->body();                            //hier  wird den body einer Coroutine aufgerufen
    obj->exit();                            //wenn der body fertig  ist. dann wird exit aufgerufen
}

void Coroutine::setup(void* tos)    {             // erstmal prüfe ob der Top of the Stack 0 ist ! 
    if (tos == 0) {
        return;
    }
    else  {                            
        SetupStackFrame* frame = ((SetupStackFrame*)tos)-1;   //StackFrame setup wird hier erstellt und richtig platziert 
        frame->edi = 0;                     //nicht flüchtige Registern den Standartwert geben für edi , esi , ebx , epb 
        frame->esi = 0;
        frame->ebx = 0;
        frame->ebp = 0;
        frame->coroutine = startup;          //startup aufrufen zum ausführen der Coroutine
        frame->rertAdresse = 0;              // Rücksprung Adresse 
        frame->obj = this;                  // eine Parameter
        this->sp = frame;                   // hier wird der Stackpointer einer Coroutine zu dem Top of the Stack hingebracht. 
    }

}

