#include "thread/ActivityScheduler.h"
#include "interrupts/IntLock.h"
#include "device/CPU.h"


void ActivityScheduler :: kill(Activity* act){
	IntLock lock;	
	act -> changeTo(Activity :: ZOMBIE);  					// act wird auf zombi gestellt 

	if (((Activity*)active())== act)  {      				// wenn er lief, dann nächste von Read list duch reschudule starten 
		this-> reschedule();                               // nachdem er gefunden, wir den nächsten starten
	}
	remove((Schedulable*)act);							    // wenn nicht dann wird von dem list genommen 	
}

void ActivityScheduler :: exit(){	
IntLock lock;							
kill((Activity*)active());								// hier wird erstmal gekillt und dann nächste Prozesse duch reschdule aufgerufen 
reschedule();
}
void ActivityScheduler :: activate(Schedulable* to)
{
	/*
	hier wird ein Prozess Aktieviert, indem den Laufenden Prozess in ReadyList gesendet und dann der zu Akievernde Prozess wird aktievert 
	*/
	
	Activity* currAct = (Activity*)active();	//aktuell laufender Prozess in CurAct speichern
	Activity* nextAct = (Activity*)to;		//naechster laufender Prozess  in nextAct speichen

	
	if(nextAct != 0){						// prüfe ob der nächste prozess existiert 

		if(nextAct -> isBlocked() || nextAct -> isZombie()){
			//hier wird gepruft, ob den nächster Prozess ist nicht lauffaehig  dann haben wir abbruch
			return;
		}else{
			if(!(currAct -> isBlocked() ||currAct -> isZombie() || currAct == nextAct)){
				currAct -> changeTo(Activity :: READY);   // dann in Rady zustand bringen 
				scheduler.schedule(currAct); //zum Readlist  wieder bringen
			}
			
			nextAct -> changeTo(Activity :: RUNNING);
			dispatch(nextAct);	//nächstem Prozess durch dispather vermerken                            
		}
	}else{
		if (currAct -> isRunning()){     						// hier läuft der Prozess weiter 
			
		}else{
			if(test==true)
			{
				while (nextAct == 0) {         						//hier wird nach einem laufffihigen Prozess gesucht. 
								test= false;											   
								nextAct = (Activity *) readylist.dequeue();  // wenn nextAct nicht existiert , dann entfernen aus der ReadyList wegnehmen
								CPU::enableInterrupts();
								CPU::halt();
								CPU::disableInterrupts();

				}
				test=true;

				if(nextAct !=0)
				{
					if(!(currAct -> isBlocked() ||currAct -> isZombie() || currAct == nextAct)){
						currAct -> changeTo(Activity :: READY);
					}
				nextAct->changeTo(Activity::RUNNING);
				dispatch(nextAct); // nächste prozess abfrage !! 
				}

			}
		
		}
		
	}
	
}

void ActivityScheduler :: suspend(){
	IntLock lock;
	((Activity*)active()) -> changeTo(Activity :: BLOCKED);  // laufende prozess blockieren 
	this -> reschedule();                                    // dann wird hier der nächsten Prozess von der Liste gestertet
}

